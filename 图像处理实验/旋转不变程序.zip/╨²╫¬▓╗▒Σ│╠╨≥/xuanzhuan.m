  image_1=imread('rec1.bmp');  %��ȡͼ��
  S=size(image_1);
  [X,Y]=meshgrid(1:S(1),1:S(2))
coef_all=fft2(image_1);               %��DFT�任
  f = fftshift(log(1+abs(coef_all)));
   figure,
  subplot(2, 2, 1);
  imshow(image_1);
   title('ԭͼ��');
  subplot(2, 2, 2);
 % mesh(X,Y,abs(fftshift(coef_all))); %
   imshow(f, []);
  title('Ƶ��ͼDFT');
   image_2=imread('rec2.bmp');  %��ȡͼ��
coef_all=fft2(image_2);               %��DFT�任
  f = fftshift(log(1+abs(coef_all)));
    subplot(2, 2, 3);
  imshow(image_2);
   title('��תͼ��');
  subplot(2, 2, 4);
  imshow(f, []);
   title('��תͼ��Ƶ��ͼ');